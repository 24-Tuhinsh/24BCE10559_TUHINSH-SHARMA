const express = require("express");

const router = express.Router();

const Student = require("../models/Student");

router.post("/", async (req, res) => {

    try {

        const student = new Student(req.body);

        const savedStudent = await student.save();
        
        console.log("New Student Added:");
        console.log(savedStudent);

        res.status(201).json(savedStudent);

    } catch (error) {

        res.status(500).json(error);
    }
});

router.get("/", async (req, res) => {

    try {

        const students = await Student.find().populate("department");
        console.log("Students With Department Mapping:");
        console.log(JSON.stringify(students, null, 2));
        res.json(students);

    } catch (error) {

        res.status(500).json(error);
    }
});

router.put("/:id", async (req, res) => {

    try {

        const updatedStudent = await Student.findByIdAndUpdate(

            req.params.id,
            req.body,
            { new: true }
        );
        console.log("Student Updated:");
        console.log(updatedStudent);
        res.json(updatedStudent);

    } catch (error) {

        res.status(500).json(error);
    }
});

router.delete("/:id", async (req, res) => {

    try {

        await Student.findByIdAndDelete(req.params.id);

        res.json({
            message: "Student Deleted Successfully"
        });
        console.log("Student Deleted:");
        console.log(req.params.id);

    } catch (error) {

        res.status(500).json(error);
    }
});

module.exports = router;