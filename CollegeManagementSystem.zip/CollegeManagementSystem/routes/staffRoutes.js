const express = require("express");

const router = express.Router();

const Staff = require("../models/Staff");

// add new staff

router.post("/", async (req, res) => {

    try {

        const staff = new Staff(req.body);

        const savedStaff = await staff.save();

        console.log("New Staff Added:");
        console.log(savedStaff);

        res.status(201).json(savedStaff);

    } catch (error) {

        res.status(500).json(error);
    }
});


// get staffs 

router.get("/", async (req, res) => {

    try {

        const staffs = await Staff.find()
        .populate("department");

        console.log("Staff With Department Mapping:");
        console.log(JSON.stringify(staffs, null, 2));

        res.json(staffs);

    } catch (error) {

        res.status(500).json(error);
    }
});


// update staff

router.put("/:id", async (req, res) => {

    try {

        const updatedStaff = await Staff.findByIdAndUpdate(

            req.params.id,
            req.body,
            { new: true }

        );

        console.log("Staff Updated:");
        console.log(updatedStaff);

        res.json(updatedStaff);

    } catch (error) {

        res.status(500).json(error);
    }
});


// delete staff

router.delete("/:id", async (req, res) => {

    try {

        await Staff.findByIdAndDelete(req.params.id);

        console.log("Staff Deleted:");
        console.log(req.params.id);

        res.json({
            message: "Staff Deleted Successfully"
        });

    } catch (error) {

        res.status(500).json(error);
    }
});


module.exports = router;