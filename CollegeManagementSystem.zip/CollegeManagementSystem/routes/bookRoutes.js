const express = require("express");

const router = express.Router();

const Book = require("../models/Book");


// CREATE BOOK

router.post("/", async (req, res) => {

    try {

        const book = new Book(req.body);

        const savedBook = await book.save();

        console.log("New Book Added:");
        console.log(savedBook);

        res.status(201).json(savedBook);

    } catch (error) {

        res.status(500).json(error);
    }
});


// GET ALL BOOKS

router.get("/", async (req, res) => {

    try {

        const books = await Book.find()
        .populate("issuedTo");

        console.log("Books With Student Mapping:");
        console.log(JSON.stringify(books, null, 2));

        res.json(books);

    } catch (error) {

        res.status(500).json(error);
    }
});


// UPDATE BOOK

router.put("/:id", async (req, res) => {

    try {

        const updatedBook = await Book.findByIdAndUpdate(

            req.params.id,
            req.body,
            { new: true }

        );

        console.log("Book Updated:");
        console.log(updatedBook);

        res.json(updatedBook);

    } catch (error) {

        res.status(500).json(error);
    }
});


// DELETE BOOK

router.delete("/:id", async (req, res) => {

    try {

        await Book.findByIdAndDelete(req.params.id);

        console.log("Book Deleted:");
        console.log(req.params.id);

        res.json({
            message: "Book Deleted Successfully"
        });

    } catch (error) {

        res.status(500).json(error);
    }
});


module.exports = router;