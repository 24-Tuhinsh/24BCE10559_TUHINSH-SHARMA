const express = require("express");

const router = express.Router();

const Department = require("../models/Department");


// CREATE DEPARTMENT

router.post("/", async (req, res) => {

    try {

        const department = new Department(req.body);

        const savedDepartment = await department.save();

        console.log("New Department Added:");
        console.log(savedDepartment);

        res.status(201).json(savedDepartment);

    } catch (error) {

        res.status(500).json(error);
    }
});


// GET ALL DEPARTMENTS

router.get("/", async (req, res) => {

    try {

        const departments = await Department.find();

        console.log("All Departments:");
        console.log(JSON.stringify(departments, null, 2));

        res.json(departments);

    } catch (error) {

        res.status(500).json(error);
    }
});


// UPDATE DEPARTMENT

router.put("/:id", async (req, res) => {

    try {

        const updatedDepartment = await Department.findByIdAndUpdate(

            req.params.id,
            req.body,
            { new: true }

        );

        console.log("Department Updated:");
        console.log(updatedDepartment);

        res.json(updatedDepartment);

    } catch (error) {

        res.status(500).json(error);
    }
});


// DELETE DEPARTMENT

router.delete("/:id", async (req, res) => {

    try {

        await Department.findByIdAndDelete(req.params.id);

        console.log("Department Deleted:");
        console.log(req.params.id);

        res.json({
            message: "Department Deleted Successfully"
        });

    } catch (error) {

        res.status(500).json(error);
    }
});


module.exports = router;