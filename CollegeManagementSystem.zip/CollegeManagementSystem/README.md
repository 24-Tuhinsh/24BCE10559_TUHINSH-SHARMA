# College Management System

**Tuhinsh Sharma**
B.Tech CSE Student

---

## About Project

this project is for manage college data like Students, Staff, Departments and Books using Node.js and MongoDB.

i made this project for learning backend development. there is no frontend, i tested all apis using Postman.

---

## Technologies Used

- Node.js
- Express.js
- MongoDB
- Mongoose
- Postman
- VS Code

---
## Versions

- Node.js - v22.13.1
- npm - 11.1.0
- Express.js - 5.2.1
- Mongoose - 9.7.0
- Nodemon - 3.1.14
- MongoDB - 8.0

## How to Run

first install packages:

```bash
npm install express mongoose nodemon
```

then run:

```bash
node server.js
```

---

## Database

Connection:

```bash
mongodb://127.0.0.1:27017/collegeDB
```

Collections used:
- departments
- students
- staffs
- books

---

## Modules

**Department** - stores name and hod name

**Student** - stores name, email, age and department

**Staff** - stores name, designation, salary and department

**Book** - stores title, author, price and which student it is issued to

---

## API Endpoints

### Departments
- GET /departments
- POST /departments
- PUT /departments/:id
- DELETE /departments/:id

### Students
- GET /students
- POST /students
- PUT /students/:id
- DELETE /students/:id

### Staffs
- GET /staffs
- POST /staffs
- PUT /staffs/:id
- DELETE /staffs/:id

### Books
- GET /books
- POST /books
- PUT /books/:id
- DELETE /books/:id

---

## Features

- CRUD operations for all modules
- REST APIs
- MongoDB with Mongoose
- relationships between collections using populate()

---