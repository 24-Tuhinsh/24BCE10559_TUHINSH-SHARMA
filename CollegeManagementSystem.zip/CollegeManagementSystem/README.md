# College Management System

## About the Project

This is a backend-based College Management System developed using Node.js, Express.js, MongoDB, and Mongoose.

The main purpose of this project is to manage college data such as Students, Staff, Departments, and Books. The project performs CRUD (Create, Read, Update, Delete) operations using REST APIs and stores all data in MongoDB.

The project does not have a frontend interface. All APIs were tested using Postman, and MongoDB Compass was used to view and manage the database.

---

## Technologies Used

- Node.js
- Express.js
- MongoDB
- Mongoose
- Postman
- MongoDB Compass
- VS Code

---

## Software Versions

- Node.js : v22.13.1
- npm : 11.1.0
- Express.js : 5.2.1
- Mongoose : 9.7.0
- Nodemon : 3.1.14
- MongoDB Server : 8.x

---

## Installation

Install the required packages:

```bash
npm install express mongoose nodemon
```

Run the project:

```bash
node server.js
```

or

```bash
npx nodemon server.js
```

---

## Database Configuration

Connection URL:

```bash
mongodb://127.0.0.1:27017/collegeDB
```

Database Name:

```text
collegeDB
```

Collections:

- departments
- students
- staffs
- books

---

## Project Modules

### Department Module
Stores department information such as:
- Department Name
- HOD Name

### Student Module
Stores:
- Student Name
- Email
- Age
- Department Reference

### Staff Module
Stores:
- Staff Name
- Designation
- Salary
- Department Reference

### Book Module
Stores:
- Book Title
- Author
- Price
- Issued Student Reference

---

## Relationships Used

### Student → Department
Many students can belong to one department.

### Staff → Department
Many staff members can belong to one department.

### Book → Student
A book can be issued to a student using MongoDB references.

The relationships are implemented using Mongoose references and populate().

---

## REST API Methods

- GET → Fetch Data
- POST → Insert Data
- PUT → Update Data
- DELETE → Remove Data

---

## API Endpoints

### Departments

- GET /departments
- POST /departments
- PUT /departments/:id
- DELETE /departments/:id

### Students

- GET /students
- POST /students
- PUT /students/:id
- DELETE /students/:id

### Staffs

- GET /staffs
- POST /staffs
- PUT /staffs/:id
- DELETE /staffs/:id

### Books

- GET /books
- POST /books
- PUT /books/:id
- DELETE /books/:id

---

## Features

- CRUD Operations
- RESTful APIs
- MongoDB Integration
- Mongoose ODM
- Collection Relationships
- Populate Mapping
- Postman API Testing
- MongoDB Compass Support

---

## Learning Outcome

Through this project, I learned:

- Backend development using Node.js and Express.js
- Database operations using MongoDB
- Creating REST APIs
- Implementing CRUD functionality
- Working with MongoDB relationships
- Using Mongoose populate()
- Testing APIs using Postman

---

## Developed By

**Tuhinsh Sharma**

B.Tech CSE Student