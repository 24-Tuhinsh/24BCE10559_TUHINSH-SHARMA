const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema({

    title: {
        type: String,
        required: true
    },

    author: {
        type: String,
        required: true
    },

    price: {
        type: Number,
        required: true
    },

    issuedTo: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Student"
    }

});

module.exports = mongoose.model("Book", bookSchema);