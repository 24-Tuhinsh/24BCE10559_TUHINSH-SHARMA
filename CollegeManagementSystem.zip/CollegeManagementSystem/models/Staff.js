const mongoose = require("mongoose");

const staffSchema = new mongoose.Schema({

    name: {
        type: String,
        required: true
    },

    designation: {
        type: String,
        required: true
    },

    salary: {
        type: Number,
        required: true
    },

    department: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Department"
    }

});

module.exports = mongoose.model("Staff", staffSchema);