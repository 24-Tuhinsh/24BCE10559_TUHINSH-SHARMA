const express = require("express");
const mongoose = require("mongoose");

const app = express();

app.use(express.json());

app.use((req, res, next) => {

    console.log(`Request Method: ${req.method}`);
    console.log(`Request URL: ${req.url}`);

    next();
});

mongoose.connect("mongodb://127.0.0.1:27017/collegeDB")
.then(() => {
    console.log("=================================");
    console.log("MongoDB Connected Successfully");
    console.log("Database: collegeDB");
    console.log("=================================");
})
.catch((err) => console.log(err));

const departmentRoutes = require("./routes/departmentRoutes");
const studentRoutes = require("./routes/studentRoutes");
const staffRoutes = require("./routes/staffRoutes");
const bookRoutes = require("./routes/bookRoutes");

app.use("/departments", departmentRoutes);
app.use("/students", studentRoutes);
app.use("/staffs", staffRoutes);
app.use("/books", bookRoutes);

app.get("/", (req, res) => {
    res.send("College Management System Running");
});

app.listen(5000, () => {
    console.log("Server running on port 5000");
});